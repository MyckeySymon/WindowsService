﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsServiceNCR.Tests
{
    internal interface IDatabaseService
    {
        void InsertRecord(string hardwareType, double value);
        void InsertCpu(string cpuModel, string cpuSerNum);
        void InsertHdd(string hddModel, string hddSerNum);
        void InsertRamMemory(string ramMemoryModel, string ramMemorySerial);
    }
}

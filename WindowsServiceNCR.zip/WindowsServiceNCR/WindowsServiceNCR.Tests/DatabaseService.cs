﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using WindowsServiceNCR.Data;



namespace WindowsServiceNCR.Tests
{
    public class DatabaseService : IDatabaseService
    {
        public void InsertRecord(string hardwareType, double value)
        {
            // implementation data in database
           // InsertData.InsertRecord(hardwareType, value);
        }

        public void InsertCpu(string cpuModel, string cpuSerNum)
        {
            // implementation data in database
           // InsertData.InsertCpu(cpuModel, cpuSerNum);
        }

        public void InsertHdd(string hddModel, string hddSerNum)
        {
            // implementation data in database
           // InsertData.InsertHdd(hddModel, hddSerNum);
        }

        public void InsertRamMemory(string ramMemoryModel, string ramMemorySerial)
        {
            //implementation data in database
          //  InsertData.InsertRamMemory(ramMemoryModel, ramMemorySerial);
        }
    }

}

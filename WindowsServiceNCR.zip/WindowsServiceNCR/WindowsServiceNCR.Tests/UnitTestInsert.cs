using Moq;

namespace WindowsServiceNCR.Tests
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void InsertIntoDb_Successful()
        {
            Assert.Pass();
        }

        [Test]
        public void InsertIntoDb_Failed()
        {
         //   _objeck.Setup()
            Assert.Pass();
        }
    }
}
﻿using System;
using System.Diagnostics;
using System.IO;
using System.ServiceProcess;
using System.Text;
using System.Timers;
using WindowsServiceNCR.Common;
using WindowsServiceNCR.Data;


namespace WindowsServiceNCR
{
    public partial class Service1 : ServiceBase
    {
        private Timer timer;
        private int interval = 300000; //2000;
        private PerformanceCounter cpuCounter;

        public Service1()
        {
            InitializeComponent();
            LoggConf.LoggConfiguration();
        }

        protected override void OnStart(string[] args)
        {
            CreateTable.CreateTables();
            cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
            timer = new Timer(interval);
            timer.Elapsed += new ElapsedEventHandler(OnElapsedTime);
            timer.Enabled = true;
        }

        private void OnElapsedTime(object sender, ElapsedEventArgs e)
        {
            double cpuUsage = cpuCounter.NextValue();

            InsertData.InsertRecord("CPU", cpuUsage);
            InsertData.InsertCpu(DetailsComponents.cpuModel,  DetailsComponents.cpuSerNum);
            InsertData.InsertHdd(DetailsComponents.hddModel,  DetailsComponents.hddSerNum);
            InsertData.InsertRamMemory(DetailsComponents.ramModel, DetailsComponents.ramSerNum);

            // check if exist and create folder "Logs"
            string logsFolderPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");
            if (!Directory.Exists(logsFolderPath))
            {
                Directory.CreateDirectory(logsFolderPath);
            }

            // check if exist and create log file "LogsDetail.txt"
            string logFilePath = Path.Combine(logsFolderPath, $"LogsDetail_{DateTime.Now:yyyy-MM-dd}.txt");  // "LogsDetail_" + DateTime.Now.ToString("yyyy-MM-dd") + ".txt");
            bool fileExists = File.Exists(logFilePath);

            using (StreamWriter sw = new StreamWriter(logFilePath, true, Encoding.UTF8))
            {
                if (!fileExists)
                {
                    sw.WriteLine("Log Entries - " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    sw.WriteLine("---------------------------------------------");
                }

                // insert data in log file
                sw.WriteLine("Log Entries - " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                sw.WriteLine($"CPU Model: {DetailsComponents.cpuModel}");
                sw.WriteLine($"HDD Model: {DetailsComponents.hddModel}");         
                sw.WriteLine($"RAM Model: {DetailsComponents.ramModel}");
                sw.WriteLine("---------------------------------------------");
            }
        }

        protected override void OnStop()
        {
            timer.Enabled = false;
        }
    }
}
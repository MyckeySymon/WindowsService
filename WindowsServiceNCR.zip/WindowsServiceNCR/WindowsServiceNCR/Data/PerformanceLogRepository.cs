﻿
namespace WindowsServiceNCR.Common
{
    internal static class PerformanceLogRepository
    {
           public static string connectionString = "Data Source= C:\\Database\\database.db;";

        //create dinamicly database
        //public static void SetupDatabase(string databaseFilePath)
        //{
        //    LoggConf.LoggConfiguration();

        //    try
        //    {
        //        // Kreiraj bazu ako ne postoji
        //        if (!System.IO.File.Exists(databaseFilePath))
        //        {
        //            SQLiteConnection.CreateFile(databaseFilePath);

        //            using (SQLiteConnection connection = new SQLiteConnection($"Data Source={databaseFilePath};Version=3;"))
        //            {
        //                connection.Open();
        //                using (SQLiteCommand command = new SQLiteCommand(connection))
        //                {
        //                    // Kreiraj tabele
        //                    command.CommandText = "CREATE TABLE IF NOT EXISTS Records (Id INTEGER PRIMARY KEY, " +
        //                                            "hardware_type_id INTEGER, " +
        //                                            "value INTEGER, " +
        //                                            "create_date DATETIME, " +
        //                                            "FOREIGN KEY(hardware_type_id) " +
        //                                            "REFERENCES HardwareTypes(Id))";
        //                    command.ExecuteNonQuery();

        //                    command.CommandText = "CREATE TABLE IF NOT EXISTS HardwareTypes (Id INTEGER PRIMARY KEY, " +
        //                                         "Model VARCHAR(255), " +
        //                                         "AdditionalInfo VARCHAR(255))";
        //                    command.ExecuteNonQuery();
        //                }
        //            }

        //            Log.Information($"Database created at: {databaseFilePath}");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Log.Error(ex, "Error during database setup.");
        //    }
        //}
    }
}

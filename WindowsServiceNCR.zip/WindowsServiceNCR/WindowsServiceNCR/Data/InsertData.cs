﻿using System;
using System.Data.SQLite;
using System.Data;
using Serilog;
using WindowsServiceNCR.Common;

namespace WindowsServiceNCR.Data
{
    internal class InsertData
    {
        public static void InsertRecord(string hardwareType, double value)
        {
            LoggConf.LoggConfiguration();

            using (SQLiteConnection connection = new SQLiteConnection(PerformanceLogRepository.connectionString))
            {
                connection.Open();
                try
                {
                    using (SQLiteCommand command = new SQLiteCommand(connection))
                    {
                        // Insert data in Records
                        command.CommandText = "INSERT INTO Records (hardware_type_id, value, create_date) VALUES " +
                                              "((SELECT id FROM HardwareTypes WHERE model = @model), @value, @create_date)";

                        command.Parameters.AddWithValue("@model", hardwareType);
                        command.Parameters.Add(new SQLiteParameter("@value", DbType.Double) { Value = value });
                        command.Parameters.AddWithValue("@create_date", DateTime.Now);
                        command.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "Something went wrong while inserting record.");
                }
            }
        }

        public static void InsertCpu(string cpuModel, string cpuSerNum)
        {
            LoggConf.LoggConfiguration();

            using (SQLiteConnection connection = new SQLiteConnection(PerformanceLogRepository.connectionString))
            {
                connection.Open();
                try
                {
                    using (SQLiteCommand command = new SQLiteCommand(connection))
                    {
                        // Insert data CPU in HardwareTypes
                        command.CommandText = "INSERT INTO HardwareTypes (Model, AdditionalInfo) VALUES (@model, @additionalInfo)";
                        command.Parameters.AddWithValue("@model", cpuModel);
                        command.Parameters.AddWithValue("@additionalInfo", "CPU, serial number: " + cpuSerNum);
                        command.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "Something went wrong while inserting record.");
                }
            }
        }

        public static void InsertHdd(string hddModel, string hddSerNum)
        {
            LoggConf.LoggConfiguration();

            using (SQLiteConnection connection = new SQLiteConnection(PerformanceLogRepository.connectionString))
            {
                connection.Open();
                try
                {
                    using (SQLiteCommand command = new SQLiteCommand(connection))
                    {
                        // Insert data HDD in HardwareTypes
                        command.CommandText = "INSERT INTO HardwareTypes (Model, AdditionalInfo) VALUES (@model, @additionalInfo)";
                        command.Parameters.AddWithValue("@model", hddModel);
                        command.Parameters.AddWithValue("@additionalInfo", "HDD, serial number: " + hddSerNum);
                        command.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "Something went wrong while inserting record.");
                }
            }
        }

        public static void InsertRamMemory(string ramMemoryModel, string ramMemorySerial)
        {
            LoggConf.LoggConfiguration();

            using (SQLiteConnection connection = new SQLiteConnection(PerformanceLogRepository.connectionString))
            {
                connection.Open();
                try
                {
                    using (SQLiteCommand command = new SQLiteCommand(connection))
                    {
                        // Insert data RAM in HardwareTypes
                        command.CommandText = "INSERT INTO HardwareTypes (Model, AdditionalInfo) VALUES (@model, @additionalInfo)";
                        command.Parameters.AddWithValue("@model", ramMemoryModel);
                        command.Parameters.AddWithValue("@additionalInfo", "RAM, serial number: " + ramMemorySerial);
                        command.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "Something went wrong while inserting record.");
                }
            }
        }
    }
}






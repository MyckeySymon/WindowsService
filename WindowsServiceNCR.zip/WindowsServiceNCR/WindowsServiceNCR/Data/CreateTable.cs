﻿using Serilog;
using System;
using System.Data.SQLite;
using WindowsServiceNCR.Common;


namespace WindowsServiceNCR.Data
{
    internal class CreateTable
    {

        public static void CreateTables()
        {
            LoggConf.LoggConfiguration();

            using (SQLiteConnection connection = new SQLiteConnection(PerformanceLogRepository.connectionString))
            {
                connection.Open();
                try
                {
                    using (SQLiteCommand command = new SQLiteCommand(connection))
                    {
                        // check and create table Records
                        command.CommandText = "CREATE TABLE IF NOT EXISTS Records (Id INTEGER PRIMARY KEY, " +
                                                                                    "hardware_type_id INTEGER, " +
                                                                                    "value INTEGER, " +
                                                                                    "create_date DATETIME, " +
                                                                                    "FOREIGN KEY(hardware_type_id) " +
                                                                                    "REFERENCES HardwareTypes(Id))";
                        command.ExecuteNonQuery();

                        // check and create table HardwareTypes
                        command.CommandText = "CREATE TABLE IF NOT EXISTS HardwareTypes (Id INTEGER PRIMARY KEY, " +
                                                                                         "Model VARCHAR(255), " +
                                                                                         "AdditionalInfo VARCHAR(255))";
                        command.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "Error during table creation.");
                }
            }
        }
    }
}

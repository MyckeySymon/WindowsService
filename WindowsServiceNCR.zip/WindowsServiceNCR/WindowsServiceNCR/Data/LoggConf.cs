﻿using Serilog;

namespace WindowsServiceNCR.Data
{
    internal class LoggConf
    {
        public static void LoggConfiguration()
        {
            string executableLocation = System.Reflection.Assembly.GetExecutingAssembly().Location;
            string logFilePath = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(executableLocation), "log.txt");

            Log.Logger = new LoggerConfiguration()
                .WriteTo.Console()
                .WriteTo.File(logFilePath, rollingInterval: RollingInterval.Day)
                .CreateLogger();
        }
    }
}

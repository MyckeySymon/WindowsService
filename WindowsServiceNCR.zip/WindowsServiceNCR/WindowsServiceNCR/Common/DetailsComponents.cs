﻿using Serilog;
using System;
using System.Management;
using WindowsServiceNCR.Data;

namespace WindowsServiceNCR.Common
{
    internal class DetailsComponents
    { 
        public static string ramModel = GetRAMmodel();
        public static string ramSerNum = GetRAMserial();
        public static string cpuModel = GetCpuModel();
        public static string cpuSerNum = GetCpuSerialNum();
        public static string hddModel = GetHardDiskModel();
        public static string hddSerNum = GetHDDSerialNum();

        private static string GetRAMmodel()
        {
            LoggConf.LoggConfiguration();
            string ramSerNum = "N/A";

            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMemory");

                foreach (ManagementObject obj in searcher.Get())
                {
                    ramSerNum = obj["Manufacturer"].ToString();
                    break;
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Domething wrong!!!.");
            }

            return ramSerNum;
        }

        private static string GetRAMserial()
        {
            string ramSerNum = "N/A";

            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMemory");

                foreach (ManagementObject obj in searcher.Get())
                {
                    ramSerNum = obj["SerialNumber"].ToString();
                    break;
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Domething wrong!!!.");
            }

            return ramSerNum;
        }

        private static string GetCpuModel()
        {
            string cpuModel = "N/A";

            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_Processor");

                foreach (ManagementObject obj in searcher.Get())
                {
                    cpuModel = obj["Name"].ToString();
                    break;
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Something wrong_GetCpuModel!!!.");
            }

            return cpuModel;
        }

        private static string GetCpuSerialNum()
        {
            string cpuSerNum = "N/A";

            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_Processor");

                foreach (ManagementObject obj in searcher.Get())
                {
                    cpuSerNum = obj["ProcessorId"].ToString();
                    break;
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Something wrong_GetCpuSerialNum!!!.");
            }

            return cpuSerNum;
        }

        private static string GetHardDiskModel()
        {
            string hddModel = "N/A";

            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive");

                foreach (ManagementObject obj in searcher.Get())
                {
                    hddModel = obj["Name"].ToString();
                    break;
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Something wrong_GetHardDiskModel!!!.");
            }
            return hddModel;
        }

        private static string GetHDDSerialNum()
        {
            string hddSerNum = "N/A";

            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive");

                foreach (ManagementObject obj in searcher.Get())
                {
                    hddSerNum = obj["Model"].ToString();
                    break;
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Something wrong_GetSerialNum!!!.");
            }

            return hddSerNum;
        }
    }
}
